# Setup
On local computer, using the environment you previously had.
Install Pytorch >= 1.8 and torchvision>= 0.9.0 (You can check your versions with `pip list`).

Then, install the requirements from this directory:
```
pip install -r requirements.txt
```
If you are on the Cybele/tulipan computers, use:
```
pip install --user -r requirements.txt
```

The environment is already fixed on the tdt4265.idi.ntnu.no server!