import omegaconf
print(f'omegaconf={omegaconf.__version__}')
